package com.example.team_pj_springboot.service;

public class ApprovalServiceImpl {
 
}
